"""
GPT를 사용한 해시태그 추천 체인
"""
import requests
import os
from pathlib import Path

# OpenAI를 사용한 해시태그 생성
openai_client = None
OPENAI_API_KEY = None

try:
    from openai import OpenAI
    from dotenv import load_dotenv
    
    # 환경변수 로드 (BOM 문제 방지를 위해 여러 방법 시도)
    env_path = Path(__file__).resolve().parents[1] / ".env"
    print(f"[INFO] .env 파일 경로: {env_path}")
    print(f"[INFO] .env 파일 존재: {env_path.exists()}")
    
    # dotenv 로드
    load_dotenv(env_path, override=True)
    
    # 환경변수에서 API 키 가져오기
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
    
    # 직접 파일에서 읽기 (fallback)
    if not OPENAI_API_KEY and env_path.exists():
        try:
            with open(env_path, 'r', encoding='utf-8-sig') as f:
                for line in f:
                    line = line.strip()
                    if line.startswith('OPENAI_API_KEY='):
                        OPENAI_API_KEY = line.split('=', 1)[1].strip()
                        break
        except Exception as read_err:
            print(f"[WARN] .env 파일 직접 읽기 실패: {read_err}")
    
    if OPENAI_API_KEY:
        openai_client = OpenAI(api_key=OPENAI_API_KEY)
        print(f"[SUCCESS] OpenAI 클라이언트 초기화 성공 (API Key: {OPENAI_API_KEY[:20]}...)")
    else:
        print("[WARN] OPENAI_API_KEY가 설정되지 않았습니다.")
        
except (ImportError, Exception) as e:
    print(f"[ERROR] OpenAI 초기화 실패: {e}")
    import traceback
    traceback.print_exc()
    openai_client = None


def extract_dong_from_coordinates(latitude, longitude):
    """위도/경도를 기반으로 동(읍/면/리) 정보를 추출합니다. (역지오코딩 API 우선, GPT fallback)"""
    data = None
    
    try:
        # 1. 역지오코딩 API로 위치 정보 가져오기
        response = requests.get(
            f"https://api.bigdatacloud.net/data/reverse-geocode-client?latitude={latitude}&longitude={longitude}&localityLanguage=ko",
            timeout=3
        )
        if response.status_code == 200:
            data = response.json()
            print(f"[DEBUG] 역지오코딩 API 응답: city={data.get('city')}, locality={data.get('locality')}")
            
            # 2. localityInfo에서 동/읍/면/리 직접 추출
            locality_info = data.get("localityInfo", {})
            informative = locality_info.get("informative", [])
            administrative = locality_info.get("administrative", [])
            
            # informative에서 동/읍/면/리 찾기
            for info in informative:
                name = info.get("name", "")
                if name and any(name.endswith(x) for x in ["동", "읍", "면", "리"]):
                    print(f"[SUCCESS] 동 정보 추출 (informative): {name}")
                    return name
            
            # administrative에서 동/읍/면/리 찾기
            for info in administrative:
                name = info.get("name", "")
                if name and any(name.endswith(x) for x in ["동", "읍", "면", "리"]):
                    print(f"[SUCCESS] 동 정보 추출 (administrative): {name}")
                    return name
            
            # 3. locality에서 동/읍/면/리 찾기
            locality = data.get("locality", "")
            if locality and any(locality.endswith(x) for x in ["동", "읍", "면", "리"]):
                print(f"[SUCCESS] 동 정보 추출 (locality): {locality}")
                return locality
            
            # 4. city에서 동/읍/면/리 찾기
            city = data.get("city", "")
            if city and any(city.endswith(x) for x in ["동", "읍", "면", "리"]):
                print(f"[SUCCESS] 동 정보 추출 (city): {city}")
                return city
        else:
            print(f"[WARN] 역지오코딩 API 실패: {response.status_code}")
    except requests.RequestException as e:
        print(f"[WARN] 역지오코딩 API 타임아웃/오류: {e}")
    except Exception as e:
        print(f"[WARN] 역지오코딩 파싱 오류: {e}")
    
    # 5. GPT로 좌표에서 직접 추측 (역지오코딩 API 실패 시 fallback)
    if openai_client:
        try:
            # 역지오코딩 데이터가 있으면 활용
            context = ""
            if data:
                city = data.get("city", "")
                locality = data.get("locality", "")
                principal_subdivision = data.get("principalSubdivision", "")
                context = f"\n참고 정보: 시/도={principal_subdivision}, 도시={city}, 지역={locality}"
            
            prompt = f"""한국의 좌표 (위도: {latitude}, 경도: {longitude})에서 해당하는 동/읍/면/리 이름을 알려주세요.{context}

규칙:
1. 정확한 동/읍/면/리 이름만 출력 (예: "역삼동", "연동", "한림읍")
2. "동", "읍", "면", "리"로 끝나야 함
3. 다른 설명 없이 지역명만 출력
4. 모르겠으면 빈 문자열만 출력

답변:"""

            completion = openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "당신은 한국 지리 전문가입니다. 좌표를 보고 해당 위치의 동/읍/면/리를 정확히 알려줍니다."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                max_tokens=30
            )
            
            dong = completion.choices[0].message.content.strip()
            # 불필요한 문자 제거
            dong = dong.replace('"', '').replace("'", '').strip()
            
            if dong and any(dong.endswith(x) for x in ["동", "읍", "면", "리"]):
                print(f"[SUCCESS] 동 정보 추출 (GPT): {dong}")
                return dong
        except Exception as gpt_err:
            print(f"[ERROR] GPT 동 추출 오류: {gpt_err}")
    
    print(f"[WARN] 동 정보를 찾을 수 없음: lat={latitude}, lng={longitude}")
    return ""


def generate_hashtags_with_gpt(companion: str, latitude: float, longitude: float, dong: str = "") -> str:
    """GPT를 사용해서 관계, 위치(시/구/동) 정보를 결합한 MZ스럽고 인스타그램 스러운 해시태그 생성"""
    if not openai_client:
        print("[WARN] OpenAI 클라이언트가 없어 GPT 해시태그 생성 불가")
        return fallback_hashtags(companion, dong=dong)
    
    try:
        # 역지오코딩으로 상세 위치 정보 가져오기
        location_info = {"city": "", "district": "", "dong": dong, "locality": ""}
        try:
            response = requests.get(
                f"https://api.bigdatacloud.net/data/reverse-geocode-client?latitude={latitude}&longitude={longitude}&localityLanguage=ko",
                timeout=3
            )
            if response.status_code == 200:
                data = response.json()
                location_info["city"] = data.get("city", "") or data.get("principalSubdivision", "")  # 시/도
                location_info["district"] = data.get("locality", "")  # 구/군
                location_info["locality"] = data.get("localityInfo", {}).get("informative", [{}])[0].get("name", "") if data.get("localityInfo") else ""
                # dong이 없으면 locality에서 추출 시도
                if not location_info["dong"]:
                    locality = data.get("locality", "")
                    if locality and any(locality.endswith(x) for x in ["동", "읍", "면", "리"]):
                        location_info["dong"] = locality
        except Exception as geo_err:
            print(f"[WARN] 역지오코딩 오류: {geo_err}")
        
        # 관계별 바이브 & 인스타 감성 설정
        vibe_map = {
            "연인": {
                "vibe": "달달하고 설레는 커플 무드",
                "keywords": ["연애", "데이트", "럽스타그램", "커플", "설렘", "투샷"],
                "emoji_style": "💕🥰✨",
                "tone": "달콤하고 은밀한, 둘만 아는 시그널 느낌"
            },
            "가족": {
                "vibe": "따뜻하고 정겨운 가족 나들이",
                "keywords": ["가족여행", "효도여행", "가족스타그램", "행복", "소중함"],
                "emoji_style": "👨‍👩‍👧‍👦💝🏡",
                "tone": "포근하고 감사한, 세대를 아우르는 따뜻함"
            },
            "나홀로": {
                "vibe": "힐링하는 혼행러의 여유",
                "keywords": ["혼행", "혼여", "나홀로여행", "힐링", "자유", "여유"],
                "emoji_style": "🧘✨🌿",
                "tone": "자유롭고 쿨한, 나만의 시간을 즐기는 여유"
            },
            "우정": {
                "vibe": "찐친들과 터지는 케미",
                "keywords": ["우정여행", "베프", "찐친", "추억", "우정스타그램"],
                "emoji_style": "👯‍♀️🤝😂",
                "tone": "유쾌하고 활기찬, 진짜 친구만 아는 그 느낌"
            },
            "좋은사람": {
                "vibe": "좋은 인연과의 편안한 동행",
                "keywords": ["좋은사람", "인연", "동행", "편안함", "인스타"],
                "emoji_style": "☺️🤍🌸",
                "tone": "편안하고 자연스러운, 스며드는 좋은 기운"
            },
        }
        
        # companion 키 매핑 (프론트엔드에서 오는 값과 매핑)
        companion_key_map = {
            "연인": "연인",
            "가족": "가족",
            "솔로": "나홀로",
            "나홀로": "나홀로",
            "친구": "우정",
            "우정": "우정",
            "좋은사람": "좋은사람",
            "좋은 사람": "좋은사람",
        }
        mapped_companion = companion_key_map.get(companion, "좋은사람")
        vibe_info = vibe_map.get(mapped_companion, vibe_map["좋은사람"])
        
        # 위치 문맥 구성
        location_parts = []
        if location_info["city"]:
            location_parts.append(location_info["city"])
        if location_info["district"]:
            location_parts.append(location_info["district"])
        if location_info["dong"]:
            location_parts.append(location_info["dong"])
        
        location_str = " ".join(location_parts) if location_parts else "현재 위치"
        
        prompt = f"""당신은 인스타그램 해시태그 마스터입니다. MZ세대가 실제로 쓰는 트렌디한 해시태그를 만들어주세요.

📍 **상황 정보:**
- 함께하는 관계: {companion} ({vibe_info['vibe']})
- 현재 위치: {location_str}
- 좌표: 위도 {latitude}, 경도 {longitude}

🎯 **해시태그 생성 가이드:**

1. **위치 느낌 반영 (2개):**
   - 해당 지역의 분위기, 날씨, 풍경을 연상시키는 감성적 표현
   - 바다 근처면: 파도, 수평선, 해변, 물빛 등
   - 산/자연이면: 숲, 바람, 하늘, 초록 등
   - 도심이면: 골목, 카페, 거리, 야경 등

2. **관계 감성 반영 (2개):**
   - {vibe_info['tone']}
   - 관련 키워드: {', '.join(vibe_info['keywords'][:3])}
   - 함께하는 순간의 감정과 분위기

3. **MZ 트렌드 반영 (2개):**
   - 인스타에서 실제로 많이 쓰이는 스타일
   - 짧고 임팩트 있는 신조어/합성어
   - 예: ~ing, ~vlog, ~무드, ~타임, ~각, ~텐션 등

💡 **실제 인스타 해시태그 예시:**
- 커플: #럽스타그램 #오늘의데이트 #찰떡케미 #눈맞춤 #시간멈춰 #투샷각
- 가족: #가족스타그램 #행복한시간 #효도여행 #가족사진 #추억저장 #감사해
- 혼행: #나홀로여행 #혼여 #힐링타임 #여유로운하루 #나만의시간 #자유여행
- 친구: #우정스타그램 #찐친모임 #웃음터짐 #추억쌓기 #베프와 #케미폭발
- 좋은사람: #좋은인연 #편안한시간 #함께라좋아 #소소한행복 #따뜻한동행 #인연스타그램

⚠️ **규칙:**
1. 정확히 6개의 해시태그만 출력
2. '#해시태그' 형식으로 공백 구분
3. 지역명({location_str})은 직접 넣지 말고 그 느낌만 담기
4. 너무 길지 않게 (2~5글자 권장)
5. 다른 설명 없이 해시태그만!

해시태그 6개:"""

        print(f"[GPT] 해시태그 생성 시작: companion={companion}, location={location_str}, dong={dong}")
        completion = openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "당신은 인스타그램 해시태그 전문가입니다. MZ세대가 실제로 사용하는 트렌디하고 감성적인 해시태그를 생성합니다. 짧고 임팩트 있으며, SNS에서 바로 복붙해서 쓸 수 있는 자연스러운 해시태그만 생성하세요."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.95,  # 창의성 최대
            max_tokens=200
        )
        
        result = completion.choices[0].message.content.strip()
        print(f"[GPT] 해시태그 생성 결과: {result}")
        
        # 해시태그만 추출 (설명 제거)
        import re
        hashtags = re.findall(r'#\w+', result)
        
        # 동이름이 있으면 첫 번째 해시태그로 추가
        dong_hashtag = None
        if location_info["dong"] and location_info["dong"].strip():
            dong_name = location_info["dong"].strip()
            dong_hashtag = f"#{dong_name}"
            print(f"[GPT] 동이름 해시태그 추가: {dong_hashtag}")
        
        if len(hashtags) >= 6:
            final_tags = hashtags[:6]
        elif len(hashtags) > 0:
            # 부족하면 fallback으로 보완
            fallback = fallback_hashtags(companion, location=location_str, dong=dong)
            fallback_tags = re.findall(r'#\w+', fallback)
            combined = hashtags + [tag for tag in fallback_tags if tag not in hashtags]
            final_tags = combined[:6]
        else:
            fallback = fallback_hashtags(companion, location=location_str, dong=dong)
            final_tags = re.findall(r'#\w+', fallback)[:6]
        
        # 동 해시태그가 있으면 첫 번째에 추가 (중복 제거)
        if dong_hashtag:
            final_tags = [tag for tag in final_tags if tag != dong_hashtag]
            final_tags = [dong_hashtag] + final_tags[:5]  # 동 해시태그 + 나머지 5개
        
        return " ".join(final_tags)
            
    except Exception as e:
        print(f"GPT 해시태그 생성 오류: {e}")
        import traceback
        traceback.print_exc()
        return fallback_hashtags(companion, dong=dong)


def _pick_location_token(location: str = "", dong: str = "") -> str:
    """
    fallback용 '동네 토큰'을 뽑습니다.
    - 우선순위: dong > location 마지막 토큰
    - 길이: 2~3글자 정도로 압축 (너무 길면 3글자까지만)
    """
    token = (dong or "").strip()
    if not token:
        loc = (location or "").strip()
        if loc:
            token = loc.split()[-1].strip()

    # 그래도 없으면 기본값
    if not token:
        token = "우리동"  # 3글자 (fallback에서도 위치 느낌)

    token = token.replace(" ", "")

    # 너무 짧으면 보정
    if len(token) < 2:
        token = "우리동"

    # 너무 길면 3글자까지만 (예: "경기도" 3, "역삼동" 3)
    if len(token) > 3:
        token = token[:3]

    return token


def _normalize_companion(companion: str) -> str:
    """
    프론트/백에서 들어오는 다양한 관계값을 5개 카테고리로 정규화합니다.
    최종 키: 연인 | 가족 | 나홀로 | 우정 | 좋은사람
    """
    raw = str(companion or "").strip()
    if not raw:
        return "좋은사람"

    mapping = {
        # 연인
        "lover": "연인",
        "연인": "연인",
        # 가족
        "family": "가족",
        "가족": "가족",
        # 나홀로(=솔로)
        "solo": "나홀로",
        "솔로": "나홀로",
        "나홀로": "나홀로",
        # 우정(=친구)
        "friendship": "우정",
        "친구": "우정",
        "우정": "우정",
        # 좋은사람
        "goodPerson": "좋은사람",
        "좋은사람": "좋은사람",
        "좋은 사람": "좋은사람",
    }
    return mapping.get(raw, raw if raw in ["연인", "가족", "나홀로", "우정", "좋은사람"] else "좋은사람")


def fallback_hashtags(companion: str, location: str = "", dong: str = "") -> str:
    """
    GPT 실패 시 사용하는 기본 해시태그.
    - 관계별로 어울리는 MZ 톤
    - 저장된 위치(동/구 정도)를 섞어서, 대부분 5~6자(‘#’ 제외)로 출력되게 구성
    """
    key = _normalize_companion(companion)
    loc = _pick_location_token(location=location, dong=dong)

    # suffix는 2~3글자로 유지 → loc(2~3) + suffix(2~3) = 4~6글자 (대부분 5~6자)
    # “딱딱한 문장형” 대신, 실제 인스타에서 쓰는 짧은 합성어/무드 단어로 구성
    suffix_map = {
        "연인": ["데이트", "커플샷", "설렘샷", "심쿵각", "무드샷", "투샷각"],
        "가족": ["가족샷", "추억샷", "행복각", "나들이", "한컷샷", "따뜻샷"],
        "나홀로": ["혼행각", "힐링샷", "여유각", "산책각", "감성샷", "나만샷"],
        "우정": ["찐친샷", "우정샷", "텐션샷", "수다각", "웃참샷", "단체샷"],
        "좋은사람": ["인연샷", "훈훈샷", "좋은날", "고마움", "따뜻샷", "편안샷"],
    }

    suffixes = suffix_map.get(key, suffix_map["좋은사람"])
    tags = [f"#{loc}{s}" for s in suffixes[:6]]
    return " ".join(tags)


def generate_hashtags_with_location(companion: str, location: str, dong: str = "") -> str:
    """GPT를 사용해서 관계와 동네 정보를 결합한 MZ스러운 해시태그 생성"""
    if not openai_client:
        print("[WARN] OpenAI 클라이언트가 없어 GPT 해시태그 생성 불가")
        return fallback_hashtags(companion, location=location, dong=dong)
    
    try:
        import re
        
        # 관계별 톤 설정
        tone_map = {
            "연인": "달달하고 설레는 커플 무드 💕",
            "가족": "따뜻하고 정겨운 가족 나들이 👨‍👩‍👧‍👦",
            "솔로": "힐링하는 혼행러의 여유 🧘",
            "친구": "찐친들과 터지는 케미 👯‍♀️",
            "좋은사람": "좋은 인연과의 편안한 동행 ☺️",
        }
        tone = tone_map.get(companion, "캐주얼하고 트렌디한 말투")
        
        # 위치 정보 활용 (이미 가공된 동네 정보 사용)
        location_context = location if location else (f"'{dong}' 동네" if dong else "여기")
        
        # 위치에서 시/구/동 추출
        location_parts = location.split() if location else []
        si_info = ""
        gu_info = ""
        dong_info = dong if dong else ""
        for part in location_parts:
            if "시" in part or "도" in part:
                si_info = part
            elif "구" in part or "군" in part:
                gu_info = part
            elif "동" in part or "읍" in part or "면" in part:
                dong_info = part
        
        prompt = f"""당신은 MZ세대 감성의 해시태그 전문가입니다.

{companion}와 함께 {location_context}에서 보내는 순간을 상징하는 해시태그 6개를 생성해주세요.

**위치 정보:**
- 전체 지역: {location_context}
- 시/도: {si_info if si_info else "미확인"}
- 구/군: {gu_info if gu_info else "미확인"}
- 동/읍/면: {dong_info if dong_info else "미확인"}

**중요: 해시태그 6개 중 3개는 반드시 위치 정보(시/구/동)를 직접 포함해야 합니다!**
- 예: #역삼동데이트, #강남구산책, #서울감성, #고양시나들이, #흥도동일상 등
- 지역명을 자연스럽게 해시태그에 녹여주세요

**스타일 가이드:**
- {tone}
- 짧고 임팩트 있는 단어 조합
- 감성적이면서도 트렌디한 느낌
- SNS에서 실제로 쓰일 법한 자연스러운 표현
- 관계({companion})와 위치의 조화를 담은 해시태그
- MZ 트렌드 반영 (예: ~ing, ~vlog, ~무드, ~감성, ~필터, ~샷, ~데이, ~로그 등)

**예시 (참고용):**
- 연인 + 강남구 역삼동: #역삼동데이트 #강남커플 #서울밤산책 #둘만의무드 #눈빛모드 #달콤한순간
- 친구 + 고양시 흥도동: #고양시나들이 #흥도동일상 #경기도여행 #우정모드 #같이걷기 #웃음가득
- 솔로 + 제주시 연동: #제주혼행 #연동카페 #제주도힐링 #나만의시간 #혼행기록 #조용한쉼표

**규칙:**
1. '#해시태그' 형식으로 정확히 6개만 출력
2. 6개 중 3개는 반드시 위치명(시/구/동)을 포함할 것
3. 나머지 3개는 관계와 분위기를 담은 감성 해시태그
4. 설명이나 추가 텍스트 없이 해시태그만 출력
5. 각 해시태그는 공백으로 구분

해시태그:"""

        print(f"[GPT] 해시태그 생성 시작 (location 방식): companion={companion}, location={location}, dong={dong}")
        completion = openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "당신은 MZ세대 감성의 해시태그 전문가입니다. 관계와 위치 정보를 결합하여 짧고 임팩트 있는, 트렌디하고 감성적인 해시태그를 생성합니다."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.9,
            max_tokens=200
        )
        
        result = completion.choices[0].message.content.strip()
        print(f"[GPT] 해시태그 생성 결과: {result[:100]}")
        
        # 해시태그만 추출 (설명 제거)
        hashtags = re.findall(r'#\w+', result)
        if len(hashtags) >= 6:
            return " ".join(hashtags[:6])
        elif len(hashtags) > 0:
            fallback = fallback_hashtags(companion, location=location, dong=dong)
            fallback_tags = re.findall(r'#\w+', fallback)
            combined = hashtags + [tag for tag in fallback_tags if tag not in hashtags]
            return " ".join(combined[:6])
        else:
            return fallback_hashtags(companion, location=location, dong=dong)
            
    except Exception as e:
        print(f"GPT 해시태그 생성 오류 (location 방식): {e}")
        import traceback
        traceback.print_exc()
        return fallback_hashtags(companion, location=location, dong=dong)


class HashtagChainLoader:
    """해시태그 생성 체인을 관리하는 싱글톤 클래스"""
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(HashtagChainLoader, cls).__new__(cls)
        return cls._instance

    def get_hashtags(self, companion: str, latitude: float, longitude: float, dong: str = "") -> str:
        """관계, 위도/경도, 동 정보를 받아 해시태그를 생성합니다."""
        # GPT만 사용 (경도/위도 정보 포함)
        if not openai_client:
            print("[WARN] OpenAI 클라이언트가 없어 fallback 사용")
            return fallback_hashtags(companion, dong=dong)
        
        try:
            result = generate_hashtags_with_gpt(companion, latitude, longitude, dong)
            if result and result.strip():
                print(f"[SUCCESS] GPT 해시태그 생성 성공: companion={companion}, latitude={latitude}, longitude={longitude}, dong={dong}")
                print(f"[SUCCESS] 생성된 해시태그: {result}")
                return result
            else:
                print(f"[WARN] GPT 결과가 비어있음, fallback 사용")
                return fallback_hashtags(companion, dong=dong)
        except Exception as e:
            print(f"[ERROR] GPT 해시태그 생성 오류: {e}")
            import traceback
            traceback.print_exc()
            print(f"[FALLBACK] GPT 실패, fallback 사용: companion={companion}")
            return fallback_hashtags(companion, dong=dong)

    def get_hashtags_with_location(self, companion: str, location: str, dong: str = "") -> str:
        """관계와 동네 정보(문자열)를 받아 해시태그를 생성합니다."""
        if not openai_client:
            print("[WARN] OpenAI 클라이언트가 없어 fallback 사용")
            return fallback_hashtags(companion, location=location, dong=dong)
        
        try:
            result = generate_hashtags_with_location(companion, location, dong)
            if result and result.strip():
                print(f"[SUCCESS] GPT 해시태그 생성 성공 (location 방식): companion={companion}, location={location}, dong={dong}")
                print(f"[SUCCESS] 생성된 해시태그: {result}")
                return result
            else:
                print(f"[WARN] GPT 결과가 비어있음, fallback 사용")
                return fallback_hashtags(companion, location=location, dong=dong)
        except Exception as e:
            print(f"[ERROR] GPT 해시태그 생성 오류 (location 방식): {e}")
            import traceback
            traceback.print_exc()
            print(f"[FALLBACK] GPT 실패, fallback 사용: companion={companion}")
            return fallback_hashtags(companion, location=location, dong=dong)


# 싱글톤 인스턴스
hashtag_chain_loader = HashtagChainLoader()
