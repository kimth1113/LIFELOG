from django.apps import AppConfig


class DialectConverterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dialect_converter'

