from rest_framework import serializers


class ErrorResponseSerializer(serializers.Serializer):
    success = serializers.BooleanField()
    error = serializers.CharField()


class TranslateRequestSerializer(serializers.Serializer):
    text = serializers.CharField()
    target_language = serializers.CharField()


class TranslateResponseSerializer(serializers.Serializer):
    success = serializers.BooleanField()
    result = serializers.CharField(required=False, allow_blank=True)
    error = serializers.CharField(required=False, allow_blank=True)


class RecommendHashtagsRequestSerializer(serializers.Serializer):
    relationship = serializers.CharField()
    location = serializers.CharField(required=False, allow_blank=True)
    dong = serializers.CharField(required=False, allow_blank=True)
    latitude = serializers.FloatField(required=False, allow_null=True)
    longitude = serializers.FloatField(required=False, allow_null=True)


class RecommendHashtagsResponseSerializer(serializers.Serializer):
    success = serializers.BooleanField()
    hashtags = serializers.CharField(required=False, allow_blank=True)
    location = serializers.CharField(required=False, allow_blank=True)
    dong = serializers.CharField(required=False, allow_blank=True)
    error = serializers.CharField(required=False, allow_blank=True)


# 문장 배치 생성 API
class GenerateCaptionsBatchRequestSerializer(serializers.Serializer):
    spot = serializers.CharField()
    relationship = serializers.CharField()
    hashtags = serializers.CharField(required=False, allow_blank=True)
    weather = serializers.CharField(required=False, allow_blank=True)
    temperature = serializers.FloatField(required=False, allow_null=True)
    img1 = serializers.ImageField(required=False)
    img2 = serializers.ImageField(required=False)
    img3 = serializers.ImageField(required=False)


class GenerateCaptionsBatchResponseSerializer(serializers.Serializer):
    success = serializers.BooleanField()
    mz_captions = serializers.ListField(child=serializers.CharField(), required=False)
    ajae_captions = serializers.ListField(child=serializers.CharField(), required=False)
    photo_captions = serializers.ListField(child=serializers.CharField(), required=False)
    error = serializers.CharField(required=False, allow_blank=True)


class ApiInfoResponseSerializer(serializers.Serializer):
    name = serializers.CharField()
    version = serializers.CharField()
    description = serializers.CharField()
    endpoints = serializers.DictField(child=serializers.JSONField())


# 날씨 API
class GetWeatherRequestSerializer(serializers.Serializer):
    latitude = serializers.FloatField()
    longitude = serializers.FloatField()


class GetWeatherResponseSerializer(serializers.Serializer):
    success = serializers.BooleanField()
    weather = serializers.CharField(required=False, allow_blank=True)  # "맑음", "흐림", "비" 등
    temperature = serializers.FloatField(required=False)  # 현재 기온
    description = serializers.CharField(required=False, allow_blank=True)  # 상세 설명
    error = serializers.CharField(required=False, allow_blank=True)


# 최종 결과물(다운로드 PNG) 서버 저장 API
class SaveFinalResultRequestSerializer(serializers.Serializer):
    # deprecated (no longer used)
    pass


class SaveFinalResultResponseSerializer(serializers.Serializer):
    # deprecated (no longer used)
    pass
