"""
번역 로더

기존 Transformers(M2M100) 기반 번역은 Windows 환경에서 'meta tensor' 오류로 실패하는 케이스가 있어
JEJU-LOG에서는 OpenAI 기반 번역을 기본으로 사용합니다.

요구사항:
- /api/dialect/translate/ 를 통해 동적 데이터를 2차 번역
- 지원 언어: en / ja / zh
"""

import os
from pathlib import Path

from dotenv import load_dotenv

try:
    from openai import OpenAI
except Exception:
    OpenAI = None


class TranslationLoader:
    """번역 모델을 한 번만 로드하고 재사용하는 싱글톤 클래스"""
    _instance = None
    _client = None
    _cache = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(TranslationLoader, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if self._cache is None:
            self._cache = {}

        if self._client is None and OpenAI is not None:
            # backend/.env 로드 (일반적인 경로)
            try:
                base_dir = Path(__file__).resolve().parents[1]
                load_dotenv(base_dir / ".env", override=True)
            except Exception:
                pass

            api_key = os.environ.get("OPENAI_API_KEY")
            if api_key:
                self._client = OpenAI(api_key=api_key)
            else:
                self._client = None

    def translate(self, text, target_language="en", max_length=200, num_beams=5):
        """
        한국어 텍스트를 목표 언어로 번역합니다.
        OpenAI 기반 번역을 사용합니다.
        
        Args:
            text: 번역할 한국어 텍스트
            target_language: 목표 언어 코드 ("en", "ja", "zh")
        
        Returns:
            번역된 텍스트
        """
        if target_language not in ["en", "ja", "zh"]:
            raise ValueError(f"지원하지 않는 언어입니다: {target_language}")

        raw = str(text or "").strip()
        if not raw:
            return ""

        cache_key = f"{target_language}::{raw}"
        cached = self._cache.get(cache_key)
        if cached is not None:
            return cached

        if self._client is None:
            raise RuntimeError("OpenAI 클라이언트가 초기화되지 않았습니다. OPENAI_API_KEY를 확인하세요.")

        lang_name = {"en": "English", "ja": "Japanese", "zh": "Chinese"}[target_language]
        prompt = (
            "Translate the following Korean text into "
            + lang_name
            + ".\n\n"
            "Rules:\n"
            "- Output ONLY the translated text.\n"
            "- Keep proper nouns if translation is awkward.\n"
            "- Do not add quotes, bullet points, or explanations.\n\n"
            "Korean:\n"
            + raw
        )

        resp = self._client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a professional translator."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
            max_tokens=300,
        )
        out = (resp.choices[0].message.content or "").strip()
        # cache and return
        self._cache[cache_key] = out
        return out


# 싱글톤 인스턴스
translation_loader = TranslationLoader()

