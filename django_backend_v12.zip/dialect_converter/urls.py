"""
dialect_converter URL configuration.
"""
from django.urls import path
from . import views

app_name = "dialect_converter"

urlpatterns = [
    path("translate/", views.translate, name="translate"),
    path("recommend-hashtags/", views.recommend_hashtags, name="recommend_hashtags"),
    path("get-location-info/", views.get_location_info, name="get_location_info"),
    path("get-weather/", views.get_weather, name="get_weather"),
    path("generate-captions-batch/", views.generate_captions_batch_view, name="generate_captions_batch"),
    path("", views.api_info, name="api_info"),
]
