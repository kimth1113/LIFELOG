"""
API views for JEJU-LOG.
"""
import json
import os
from datetime import datetime
from pathlib import Path

from PIL import Image
from rest_framework import status
from rest_framework.decorators import api_view, parser_classes
from rest_framework.parsers import JSONParser, MultiPartParser, FormParser
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema

from .content_generator import generate_captions_batch
from .hashtag_chain import hashtag_chain_loader
from .serializers import (
    ErrorResponseSerializer,
    TranslateRequestSerializer,
    TranslateResponseSerializer,
    RecommendHashtagsRequestSerializer,
    RecommendHashtagsResponseSerializer,
    GenerateCaptionsBatchRequestSerializer,
    GenerateCaptionsBatchResponseSerializer,
    ApiInfoResponseSerializer,
    GetWeatherRequestSerializer,
    GetWeatherResponseSerializer,
)
import requests

# backend/ 디렉토리 기준 경로로 통일
ROOT_DIR = Path(__file__).resolve().parents[1]


def _sanitize_filename(name: str) -> str:
    """파일명에 위험한 문자 제거 (디렉토리 트래버설 방지)."""
    import re

    name = (name or "").strip()
    name = name.replace("\\", "/").split("/")[-1]  # 경로 제거
    # 허용: 영문/숫자/._- 만
    name = re.sub(r"[^a-zA-Z0-9._-]", "_", name)
    # 너무 짧거나 확장자 없는 경우 기본값
    if not name:
        return ""
    return name


@extend_schema(
    request=TranslateRequestSerializer,
    responses={
        200: TranslateResponseSerializer,
        400: ErrorResponseSerializer,
        500: ErrorResponseSerializer,
    },
)
@api_view(["POST"])
@parser_classes([JSONParser])
def translate(request):
    try:
        data = request.data or {}
        text = str(data.get("text", "")).strip()
        target_language = str(data.get("target_language", "en")).lower()

        if not text:
            return Response(
                {"success": False, "error": "text is required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if target_language not in ["en", "ja", "zh"]:
            return Response(
                {
                    "success": False,
                    "error": "target_language must be one of en, ja, zh.",
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        from .translation_loader import translation_loader

        translated_text = translation_loader.translate(text, target_language)

        return Response({"success": True, "result": translated_text})
    except Exception as exc:
        return Response(
            {"success": False, "error": f"server error: {exc}"},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )


@extend_schema(
    request=RecommendHashtagsRequestSerializer,
    responses={
        200: RecommendHashtagsResponseSerializer,
        400: ErrorResponseSerializer,
        500: ErrorResponseSerializer,
    },
)
@api_view(["POST"])
@parser_classes([JSONParser])
def recommend_hashtags(request):
    try:
        data = request.data or {}
        relationship = str(data.get("relationship", "")).strip()
        
        # 저장된 동네 정보 우선 사용 (Page1Home에서 이미 가져옴)
        location = str(data.get("location", "")).strip()  # "경기도 고양시 흥도동" 형식
        dong = str(data.get("dong", "")).strip()  # "흥도동" 형식
        
        # 위도/경도 (선택적)
        latitude = data.get("latitude")
        longitude = data.get("longitude")

        if not relationship:
            return Response(
                {"success": False, "error": "relationship is required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # 위도/경도가 있으면 float으로 변환
        if latitude is not None and longitude is not None:
            try:
                latitude = float(latitude)
                longitude = float(longitude)
            except (ValueError, TypeError):
                latitude = None
                longitude = None

        # 동 정보가 없고 위도/경도가 있으면 추출 시도
        if not dong and latitude is not None and longitude is not None:
            try:
                from .hashtag_chain import extract_dong_from_coordinates
                dong = extract_dong_from_coordinates(latitude, longitude)
                print(f"[API] 동 정보 추출: {dong} (위도: {latitude}, 경도: {longitude})")
            except Exception as e:
                print(f"[WARN] 동 정보 추출 오류: {e}")

        try:
            # 해시태그 생성 (동네 정보 + 관계)
            print(f"[API] 해시태그 생성 요청: relationship={relationship}, location={location}, dong={dong}")
            hashtags = None
            try:
                # location 정보를 사용해서 해시태그 생성
                hashtags = hashtag_chain_loader.get_hashtags_with_location(relationship, location, dong)
                if hashtags:
                    hashtags = hashtags.strip()
                    print(f"[API] 해시태그 생성 성공: {hashtags[:100]}")
            except Exception as chain_exc:
                print(f"[ERROR] 해시태그 체인 오류: {chain_exc}")
                import traceback
                traceback.print_exc()
            
            # 해시태그가 없거나 비어있으면 fallback 사용
            if not hashtags or not hashtags.strip():
                from .hashtag_chain import fallback_hashtags
                hashtags = fallback_hashtags(relationship, location=location, dong=dong)
                print(f"[FALLBACK] Fallback 해시태그 사용: relationship={relationship}")
            
            return Response({"success": True, "hashtags": hashtags, "dong": dong, "location": location})
        except Exception as inner_exc:
            print(f"해시태그 생성 중 최종 오류: {inner_exc}")
            import traceback
            traceback.print_exc()
            from .hashtag_chain import fallback_hashtags
            hashtags = fallback_hashtags(relationship, location=location, dong=dong)
            return Response({"success": True, "hashtags": hashtags, "dong": dong, "location": location})
    except Exception as exc:
        print(f"recommend_hashtags API 오류: {exc}")
        import traceback
        traceback.print_exc()
        return Response(
            {"success": False, "error": f"server error: {exc}"},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )


@api_view(["POST"])
@parser_classes([JSONParser])
def get_location_info(request):
    """위도/경도를 받아서 동네 정보(시/구/동) 형태로 반환"""
    try:
        data = request.data or {}
        latitude = data.get("latitude")
        longitude = data.get("longitude")
        
        if latitude is None or longitude is None:
            return Response(
                {"success": False, "error": "latitude and longitude are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        
        try:
            latitude = float(latitude)
            longitude = float(longitude)
        except (ValueError, TypeError) as e:
            return Response(
                {"success": False, "error": f"Invalid latitude/longitude: {e}"},
                status=status.HTTP_400_BAD_REQUEST,
            )
        
        # Gemini를 사용해서 동네 정보 추출
        location_str = ""
        dong = ""
        
        try:
            import requests
            from openai import OpenAI
            import os
            
            # OpenAI 클라이언트 설정
            OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
            if not OPENAI_API_KEY:
                from dotenv import load_dotenv
                from pathlib import Path
                env_path = Path(__file__).resolve().parents[1] / ".env"
                if env_path.exists():
                    with open(env_path, 'r', encoding='utf-8-sig') as f:
                        for line in f:
                            line = line.strip()
                            if line and not line.startswith('#') and '=' in line:
                                key, value = line.split('=', 1)
                                os.environ[key.strip()] = value.strip().strip('"').strip("'")
                OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
            
            openai_client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None
            
            # 1. 역지오코딩 API 시도 (Nominatim - 무료, 안정적)
            geo_data = None
            try:
                # Nominatim API 사용 (OpenStreetMap 기반)
                headers = {'User-Agent': 'JEJU-LOG/1.0'}
                response = requests.get(
                    f"https://nominatim.openstreetmap.org/reverse?lat={latitude}&lon={longitude}&format=json&addressdetails=1&accept-language=ko",
                    headers=headers,
                    timeout=5
                )
                if response.status_code == 200:
                    geo_data = response.json()
                    print(f"[API] Nominatim 응답: {geo_data.get('display_name', '')[:100]}")
            except Exception as e:
                print(f"[API] Nominatim 오류: {e}")
            
            # 2. 역지오코딩 데이터로 위치 정보 구성
            location_str = ""
            is_valid_location = False
            debug_error = ""
            
            if geo_data and geo_data.get("address"):
                addr = geo_data.get("address", {})
                
                # 한국 주소 구성 요소 추출
                country = addr.get("country", "")
                state = addr.get("state", "") or addr.get("province", "")  # 시/도
                city = addr.get("city", "") or addr.get("county", "") or addr.get("town", "")  # 시/군/구
                district = addr.get("city_district", "") or addr.get("suburb", "") or addr.get("quarter", "")  # 구/동
                neighbourhood = addr.get("neighbourhood", "") or addr.get("village", "")  # 동/리
                
                # 한국인지 확인
                if country == "대한민국" or country == "South Korea" or "Korea" in country:
                    # 주소 조합
                    parts = []
                    if state:
                        parts.append(state)
                    if city and city != state:
                        parts.append(city)
                    if district and district != city:
                        parts.append(district)
                    if neighbourhood and neighbourhood != district:
                        parts.append(neighbourhood)
                    
                    if parts:
                        location_str = " ".join(parts)
                        is_valid_location = True
                        print(f"[API] 역지오코딩 성공: {location_str}")
                else:
                    debug_error = f"한국 외 지역: {country}"
                    print(f"[API] 한국 외 지역: {country}")
            
            # 3. 역지오코딩 실패 시 OpenAI로 시도
            if not is_valid_location and openai_client:
                try:
                    prompt = f"""한국의 좌표 (위도: {latitude}, 경도: {longitude})의 주소를 알려줘.

**응답 형식:**
- 한국 내 유효한 위치: VALID|서울특별시 중구 명동
- 한국 외 또는 유효하지 않은 위치: INVALID|이유

한 줄로만 응답해. 다른 설명 없이."""

                    completion = openai_client.chat.completions.create(
                        model="gpt-4o-mini",
                        messages=[
                            {"role": "system", "content": "당신은 한국 지리 전문가입니다. 좌표를 한국 주소로 변환합니다."},
                            {"role": "user", "content": prompt}
                        ],
                        temperature=0.1,
                        max_tokens=100
                    )
                    
                    raw_response = completion.choices[0].message.content.strip()
                    print(f"[API] OpenAI 응답: {raw_response}")
                    
                    if raw_response.startswith("VALID|"):
                        is_valid_location = True
                        location_str = raw_response.replace("VALID|", "").strip()
                    elif raw_response.startswith("INVALID|"):
                        is_valid_location = False
                        debug_error = raw_response.replace("INVALID|", "").strip()
                    else:
                        # 형식이 맞지 않으면 내용으로 판단
                        import re
                        if re.search(r'(도|시|군|구|동|읍|면|리)', raw_response):
                            is_valid_location = True
                            location_str = raw_response
                        else:
                            debug_error = "위치 형식 불명확"
                            
                except Exception as e:
                    print(f"[API] OpenAI 오류: {e}")
                    debug_error = f"OpenAI 오류: {e}"
            
            # 불필요한 문자 제거
            location_str = location_str.replace('"', '').replace("'", '').replace('\n', '').strip()
            
            # 동 정보만 별도로 추출
            parts = location_str.split()
            for part in reversed(parts):
                if any(part.endswith(x) for x in ["동", "읍", "면", "리", "가"]):
                    dong = part
                    break
            
            # 최종 유효성 검증: location_str이 비어있거나 너무 짧으면 무효
            if not location_str or len(location_str) < 3:
                is_valid_location = False
                if not debug_error:
                    debug_error = "위치 정보를 확인할 수 없습니다"
            
            print(f"[API] 위치 정보 추출 완료: location={location_str}, dong={dong}, valid={is_valid_location}")
                
        except Exception as e:
            print(f"[ERROR] Gemini 위치 정보 추출 오류: {e}")
            import traceback
            traceback.print_exc()
            debug_error = str(e)
            is_valid_location = False
        
        return Response({
            "success": True,
            "is_valid": is_valid_location,  # 유효한 위치인지 여부
            "location": location_str,  # "경기도 고양시 흥도동" 형식
            "dong": dong,  # "흥도동" 형식
            "latitude": latitude,
            "longitude": longitude,
            "debug_error": debug_error
        })
        
    except Exception as exc:
        print(f"get_location_info API 오류: {exc}")
        import traceback
        traceback.print_exc()
        return Response(
            {"success": False, "error": f"server error: {exc}"},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )


@extend_schema(
    request=GenerateCaptionsBatchRequestSerializer,
    responses={
        200: GenerateCaptionsBatchResponseSerializer,
        400: ErrorResponseSerializer,
        500: ErrorResponseSerializer,
    },
)
@api_view(["POST"])
@parser_classes([MultiPartParser, FormParser])
def generate_captions_batch_view(request):
    """
    MZ감성 모드 3개 + 아재개그 모드 3개 문장을 한 번에 생성합니다.
    각 문장은 최대 20자로 제한됩니다.
    """
    try:
        spot = str(request.data.get("spot", "")).strip()
        relationship = str(request.data.get("relationship", "")).strip()
        hashtags_raw = request.data.get("hashtags", "")
        weather = str(request.data.get("weather", "")).strip()
        temperature_val = request.data.get("temperature")

        if not spot or not relationship:
            return Response(
                {"success": False, "error": "spot and relationship are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # 온도 파싱
        try:
            temperature_val = float(temperature_val) if temperature_val else None
        except (ValueError, TypeError):
            temperature_val = None

        # 해시태그 파싱
        hashtags_list = []
        if isinstance(hashtags_raw, list):
            hashtags_list = [str(item).strip() for item in hashtags_raw if str(item).strip()]
        elif isinstance(hashtags_raw, str):
            if hashtags_raw.startswith("["):
                try:
                    parsed = json.loads(hashtags_raw)
                    if isinstance(parsed, list):
                        hashtags_list = [str(item).strip() for item in parsed if str(item).strip()]
                except json.JSONDecodeError:
                    pass
            if not hashtags_list:
                hashtags_list = [h.strip() for h in hashtags_raw.split(",") if h.strip()]

        # 이미지 로드 (최대 3장)
        pil_images = []
        for i in range(1, 4):
            img_key = f"img{i}"
            if img_key in request.FILES:
                try:
                    img_file = request.FILES[img_key]
                    pil_images.append(Image.open(img_file))
                except Exception as e:
                    print(f"[WARN] 이미지 {i} 로드 실패: {e}")

        # 이미지가 없어도 진행 (프롬프트에서 처리)
        # Windows(cp949) 콘솔 인코딩 이슈로 상세 로그 출력은 생략

        result = generate_captions_batch(
            location=spot,
            images=pil_images,
            relation=relationship,
            hashtags=hashtags_list,
            weather=weather,
            temperature_val=temperature_val,
        )

        return Response({
            "success": True,
            "mz_captions": result.get("mz_captions", []),
            "ajae_captions": result.get("ajae_captions", []),
            "photo_captions": result.get("photo_captions", []),
        })

    except Exception as exc:
        try:
            print(f"[ERROR] generate_captions_batch_view error: {exc}")
        except:
            print("[ERROR] generate_captions_batch_view error (encoding issue)")
        # Windows(cp949) 콘솔에서 traceback 출력이 또 다른 UnicodeEncodeError를 유발할 수 있어 생략
        # Encode error message safely
        error_msg = str(exc).encode('utf-8', errors='replace').decode('utf-8')
        return Response(
            {"success": False, "error": f"server error: {error_msg}"},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )












@extend_schema(responses={200: ApiInfoResponseSerializer})
@api_view(["GET"])
def api_info(request):
    return Response(
        {
            "name": "JEJU-LOG API",
            "version": "2.2.0",
            "description": "Translation, hashtag, location, weather, caption batch, and save APIs.",
            "endpoints": {
                "translate": {
                    "url": "/api/dialect/translate/",
                    "method": "POST",
                    "description": "Multi-language translation.",
                },
                "recommend_hashtags": {
                    "url": "/api/dialect/recommend-hashtags/",
                    "method": "POST",
                    "description": "Recommend hashtags based on relation and spot.",
                },
                "get_location_info": {
                    "url": "/api/dialect/get-location-info/",
                    "method": "POST",
                    "description": "Get location info by coordinates.",
                },
                "get_weather": {
                    "url": "/api/dialect/get-weather/",
                    "method": "POST",
                    "description": "Get current weather info by coordinates.",
                },
                "generate_captions_batch": {
                    "url": "/api/dialect/generate-captions-batch/",
                    "method": "POST",
                    "description": "Generate multiple captions from images and tags.",
                },
            },
        }
    )


@extend_schema(
    request=GetWeatherRequestSerializer,
    responses={
        200: GetWeatherResponseSerializer,
        400: ErrorResponseSerializer,
        500: ErrorResponseSerializer,
    },
)
@api_view(["POST"])
@parser_classes([JSONParser])
def get_weather(request):
    """위도/경도 기반 실시간 날씨 정보 조회 (OpenWeatherMap API 사용)"""
    data = request.data or {}
    latitude = data.get("latitude")
    longitude = data.get("longitude")
    
    if latitude is None or longitude is None:
        return Response(
            {"success": False, "error": "latitude and longitude are required."},
            status=status.HTTP_400_BAD_REQUEST,
        )
    
    try:
        latitude = float(latitude)
        longitude = float(longitude)
    except (ValueError, TypeError) as e:
        return Response(
            {"success": False, "error": f"Invalid latitude/longitude: {e}"},
            status=status.HTTP_400_BAD_REQUEST,
        )
    
    # OpenWeatherMap API (무료 티어 사용)
    # API Key는 환경변수로 관리하거나 여기에 직접 입력
    OPENWEATHER_API_KEY = os.environ.get("OPENWEATHER_API_KEY", "")
    
    weather_str = ""
    temperature = None
    description = ""
    
    try:
        if OPENWEATHER_API_KEY:
            # OpenWeatherMap API 호출
            url = f"https://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={OPENWEATHER_API_KEY}&units=metric&lang=kr"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                weather_data = response.json()
                
                # 날씨 상태 추출
                weather_main = weather_data.get("weather", [{}])[0].get("main", "")
                weather_desc = weather_data.get("weather", [{}])[0].get("description", "")
                temp = weather_data.get("main", {}).get("temp")
                
                # 날씨 상태 한글 변환
                weather_map = {
                    "Clear": "맑음",
                    "Clouds": "흐림",
                    "Rain": "비",
                    "Drizzle": "이슬비",
                    "Thunderstorm": "천둥번개",
                    "Snow": "눈",
                    "Mist": "안개",
                    "Fog": "안개",
                    "Haze": "연무",
                }
                weather_str = weather_map.get(weather_main, weather_desc or "알 수 없음")
                temperature = temp
                description = weather_desc
            else:
                print(f"[WARN] OpenWeatherMap API 오류: {response.status_code}")
        
        # API 키가 없거나 실패 시 기본값
        if not weather_str:
            # 시간대 기반 기본 날씨 추정
            import datetime
            hour = datetime.datetime.now().hour
            if 6 <= hour < 18:
                weather_str = "맑음"
                temperature = 15.0
                description = "기본값 (API 키 없음)"
            else:
                weather_str = "맑음"
                temperature = 10.0
                description = "기본값 (API 키 없음)"
        
        return Response({
            "success": True,
            "weather": weather_str,
            "temperature": temperature,
            "description": description,
        })
        
    except Exception as e:
        print(f"[ERROR] 날씨 API 오류: {e}")
        import traceback
        traceback.print_exc()
        return Response({
            "success": True,  # 실패해도 기본값 반환
            "weather": "맑음",
            "temperature": 15.0,
            "description": f"날씨 정보 조회 실패: {e}",
        })
