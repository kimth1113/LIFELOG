"""
최종 문구 생성 모듈 (아재 모드, MZ감성 모드, 썸연애 모드)
통합 데이터 폴더에서 다양한 파일 형식 지원 (txt, pdf, img 등)
"""
import os
import base64
import re
from typing import List
from pathlib import Path
from openai import OpenAI
from PIL import Image
from io import BytesIO

# FAISS RAG 관련


# OpenAI API 설정
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")

# 기본값은 "false"로 둬서(=이미지 포함 허용) 사진중심 모드가 실제 사진 분석을 수행하도록 합니다.
# 필요하면 환경변수 TEXT_ONLY_CAPTION=true 로 강제 텍스트 전용 모드로 전환 가능합니다.
TEXT_ONLY_CAPTION = os.environ.get("TEXT_ONLY_CAPTION", "false").lower() == "true"

if not OPENAI_API_KEY:
    from dotenv import load_dotenv
    # backend/.env 우선 로드
    load_dotenv(Path(__file__).resolve().parents[1] / ".env")
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")


if not OPENAI_API_KEY:
    # Windows(cp949) 콘솔에서도 안전한 출력만 사용 (이모지 금지)
    print("[WARN] OPENAI_API_KEY 환경변수가 없습니다. 문구 생성 기능이 제한됩니다.")
    client = None
else:
    client = OpenAI(api_key=OPENAI_API_KEY)

# backend/ 기준 경로
ROOT_DIR = Path(__file__).resolve().parents[1]


def encode_image_from_pil(image: Image.Image) -> str:
    """PIL Image를 base64로 인코딩합니다."""
    buffered = BytesIO()
    if image.mode != 'RGB':
        image = image.convert('RGB')
    image.save(buffered, format="JPEG")
    return base64.b64encode(buffered.getvalue()).decode("utf-8")


def detect_child(images: List[Image.Image]) -> bool:
    """이미지에 어린아이가 있는지 감지합니다."""
    image_contents = []
    for image in images:
        encoded = encode_image_from_pil(image)
        image_contents.append({
            "type": "image_url",
            "image_url": {"url": f"data:image/jpeg;base64,{encoded}"}
        })
    
    if not image_contents:
        return False
    
    sys_prompt = (
        "너는 이미지에 '어린아이(유아/아동)'가 보이는지 여부만 판단한다.\n"
        "추측 금지. 보이면 true, 아니면 false.\n"
        "출력은 JSON 한 줄만: {\"child_present\": true/false}"
    )
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": sys_prompt},
                {"role": "user", "content": [{"type": "text", "text": "어린아이가 보이나?"}, *image_contents]},
            ],
            temperature=0.0
        )
        
        txt = (response.choices[0].message.content or "").strip().lower()
        return "true" in txt
    except Exception:
        return False


# 관계 페르소나 (아재 모드)
relation_persona_ajae = {
    "가족": "서로 잘 안다 보니 굳이 말이 많지 않은 사이.",
    "친구": "말 안 해도 상황 파악은 되는 사이.",
    "나홀로": "굳이 누구 눈치 안 보고 움직이는 상태.",
    "연인": "사진 찍을 때만 합이 맞는 사이.",
    "좋은사람": "아직 서로를 알아가는 중인 사이."
}

# 관계 페르소나 (MZ감성 모드)
relation_persona_mz = {
    "가족": "말은 적어도, 방향은 함께 맞추는 사이.",
    "친구": "가볍게 던진 한마디가 오래 남는 사이.",
    "나홀로": "결정을 남에게 맡기지 않는 상태.",
    "연인": "같은 풍경을 같은 속도로 걷는 사이.",
    "좋은사람": "서로를 알아가는 중인 사이."
}

# 관계 페르소나 (썸연애 모드)
relation_persona_sum = {
    "나홀로": "연애를 시작해도 자연스러운 상태.",
    "친구": "조금만 더 가까워질 수도 있는 사이.",
    "연인": "이미 감정이 있지만 아직 여유가 있는 관계.",
    "가족": "연애와 무관한 안정적인 관계.",
    "좋은사람": "조금만 더 가까워질 수도 있는 사이."
}


def system_prompt_ajae(relation: str) -> str:
    """아재 유머 모드 시스템 프롬프트"""
    return f"""

너는 여행 사진을 보고
웃기려고 애쓴 티는 안 나는데
읽고 나면 피식 웃게 되는 문장을 쓴다.

개그를 설명하지 않는다.
교훈으로 마무리하지 않는다.
진지해지려는 순간 한 발 물러선다.

현재 관계 설정:
{relation_persona_ajae.get(relation, relation_persona_ajae["친구"])}

[글의 방향]
- 감동보다 관찰
- 공감보다 현실
- 풍경은 배경, 사람은 주인공
- 친구들끼리 사진 올릴 때 쓰는 말투

[유머 규칙]
- 아재개그는 문장 속에 자연스럽게 섞는다
- 체력, 나이, 말 줄어든 사이, 귀찮음은 안전한 웃음 포인트
- 스스로를 살짝 낮추는 쪽이 정답

[문체 규칙]
1. 60자 정도
2. 말하듯 자연스럽게
3. 설명 금지
4. 마지막 문장은 힘 빼기

[금지]
- 교훈, 위로, 인생 조언
- 감동 포장
- 억지 웃음 표시
- 이모지, 해시태그, 제목

※ 해시태그는 분위기 참고용이다.
  문장에 직접 등장하면 실패다.
"""


def system_prompt_mz(relation: str) -> str:
    """MZ감성 모드 시스템 프롬프트"""
    return f"""

너는 여행지 포토부스 사진 위에 저장되는 감성 멘트를 쓴다.

울리려고 애쓰지 않고, 의미를 과하게 설명하지 않는다.
읽고 나서야 조용히 남는 글을 만든다.

현재 관계 설정:
{relation_persona_mz.get(relation, relation_persona_mz["친구"])}

[글의 방향]
- 위로는 직접 하지 않는다(괜찮아/힘내 금지)
- 감정은 설명하지 않고, 장면과 분위기로 대신한다
- 담백함 + 문장미(여백/리듬)가 중요하다
- 관계는 '관계'라고 말하지 말고, 행동/거리감/호흡으로만 드러낸다

[문체 규칙]
1) 2~3문장
2) 공백 포함 160~190자
3) 첫 문장: 사진 관찰 요소 2개 이상 포함(빛/거리/선/질감/움직임)
4) 둘째 문장: 장소 고유 표현(지명/지질/설화 단어 등) 1개 이상을 '설명 없이' 녹인다
   - "~이다/~로 유명하다/~라고 한다" 같은 설명체 금지
5) 조언 1줄 의무(정확히 1문장)
   - 명령형 금지(해야 해/해라/하세요/하십시오/하자)
   - 교훈/평가/정답 제시 금지
   - 선택 제안 톤: "~도 괜찮다 / ~쯤이면 충분하다 / 잠시 ~해도 된다 / ~을 남겨도 된다"
6) child_present=true이면 반드시 '아이' 단어를 1회 이상 포함
   - 나이/성별 추정 금지, 보이는 행동·거리·동작만 쓴다

[금지]
- 과한 감정어
- 힐링/치유/극복/성장 같은 단어
- AI가 쓴 티 나는 문장
- 이모지
- 해시태그
- 제목

※ 해시태그는 참고용 맥락일 뿐, 문장에 직접 등장하면 안 된다.
""".strip()




MODE_AJAE = "\uc544\uc7ac"
MODE_MZ = "MZ\uac10\uc131"
MODE_SUM = "\uc378\uc5f0\uc560"
MODE_GAG = "\uac1c\uadf8"
MODE_HUMOR_LABEL = "\uc720\uba38"
MODE_ADVICE_LABEL = "\uc870\uc5b8"
MODE_ROMANCE_LABEL = "\uc778\uc5f0"


def normalize_mode(mode: str) -> str:
    raw = (mode or "").strip()
    lower = raw.lower()
    mapping = {
        "아재개그": MODE_AJAE,
        MODE_HUMOR_LABEL: MODE_AJAE,
        "humor": MODE_AJAE,
        MODE_ADVICE_LABEL: MODE_MZ,
        "advice": MODE_MZ,
        MODE_ROMANCE_LABEL: MODE_SUM,
        "romance": MODE_SUM,
        "love": MODE_SUM,
        MODE_GAG: MODE_GAG,
        "gag": MODE_GAG,
        "current": MODE_MZ,
        "default": MODE_MZ,
    }
    if raw in mapping:
        return mapping[raw]
    if lower in mapping:
        return mapping[lower]
    return raw

def system_prompt_gag(relation: str) -> str:
    return (
        "You are a Korean gag caption writer. "
        "Write short, punchy captions for a travel photo."
    )


def system_prompt_sum(relation: str) -> str:
    """썸연애 모드 시스템 프롬프트"""
    return f"""

You write short Korean texts inspired by photos and relationship context.

Your tone should feel human and varied.
Some lines feel like casual speech.
Some lines briefly feel like a K-pop lyric passing by,
then return to everyday language.

Relationship intent:

- If alone: gently and playfully encourage future romance.
- If together: offer a warm, forward-looking blessing,
  sometimes sincere, sometimes lightly teasing.

Current relationship context:

{relation_persona_sum.get(relation, relation_persona_sum["친구"])}

[Core Direction]
- Do not repeat the same structure every time
- Vary sentence length and rhythm
- Occasionally borrow the mood of K-pop lyrics:
  timing, waiting, tonight, this moment
- Never quote real lyrics or songs

[Writing Style Rules]
1. 1–3 sentences (usually 2)
2. 60–120 Korean characters total
3. Natural spoken Korean with breathing room
4. Can flow slightly longer if rhythm feels right
5. Must not feel like a quote or a poem

[Allowed Occasionally]
- Lyric-like repetition or phrasing
- Soft imagination or hopeful timing
- Light Korean memes or playful remarks

[Strictly Avoid]
- Using actual song lyrics or titles
- Overusing memes or slang
- Dramatic declarations or confessions
- Moral lessons or advice

[Output Restrictions]
- No emojis
- No hashtags
- No title
- No explanations before or after the text

Hashtags are contextual hints only.
They must never appear directly.

The result should feel like:
A moment where a sentence almost turns into a song,
then casually stops.

Provide clear, structured, and concise explanations suitable for a Korean user.
""".strip()


def generate_captions_batch(
    location: str,
    images: List[Image.Image],
    relation: str,
    hashtags: List[str],
    weather: str = "",
    temperature_val: float = None
) -> dict:
    """
    MZ감성 모드 3개 + 아재개그 모드 3개 문장을 한 번에 생성합니다.
    각 문장은 최대 20자로 제한됩니다.
    
    Returns:
        {
            "mz_captions": ["문장1", "문장2", "문장3"],
            "ajae_captions": ["문장1", "문장2", "문장3"],
            "photo_captions": ["문장1", "문장2", "문장3"]
        }
    """
    if client is None:
        raise RuntimeError("OPENAI_API_KEY가 설정되지 않아 문구를 생성할 수 없습니다.")
    
    hashtag_context = ", ".join([h.strip() for h in hashtags if h and h.strip()])
    
    # 현재 시간대 확인 (한국 시간 기준)
    from datetime import datetime, timezone, timedelta
    kst = timezone(timedelta(hours=9))
    now = datetime.now(kst)
    current_hour = now.hour
    
    if 6 <= current_hour < 12:
        time_of_day = "아침"
    elif 12 <= current_hour < 18:
        time_of_day = "낮"
    elif 18 <= current_hour < 21:
        time_of_day = "저녁"
    else:
        time_of_day = "밤"
    
    # 날씨 정보 문자열 생성 (시간대 반영)
    weather_context = f"현재 시간대: {time_of_day} ({now.strftime('%H:%M')})"
    if weather:
        weather_context += f", 날씨: {weather}"
        if temperature_val is not None:
            weather_context += f" ({temperature_val}°C)"
    else:
        # 날씨 정보가 없으면 시간대에 맞는 기본값 사용
        if time_of_day == "밤":
            weather_context += ", 날씨: 밤하늘"
        elif time_of_day == "저녁":
            weather_context += ", 날씨: 노을"
        else:
            weather_context += ""
    
    # 이미지 인코딩 (있는 경우만)
    image_contents = []
    has_images = False
    if images and len(images) > 0:
        has_images = True
        for image in images[:3]:  # 최대 3장만 사용 (토큰 절약)
            try:
                encoded = encode_image_from_pil(image)
                image_contents.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{encoded}"}
                })
            except:
                pass
        has_images = len(image_contents) > 0
    
    # 프롬프트 구성
    if has_images:
        photo_instruction = """
**사진 분석 (중요!):**
제공된 사진을 분석하여 다음을 파악하세요:
- 사람들이 무엇을 하고 있는지 (포즈, 먹기, 걷기, 웃기 등)
- 어떤 물건/음식/풍경이 보이는지
- 분위기와 감정

문장은 사진에서 보이는 구체적인 요소를 반영해야 합니다.
"""
    else:
        photo_instruction = """
**참고:** 사진이 제공되지 않았습니다.
아래 정보만으로 문장을 작성하세요:
- 위치, 관계, 해시태그, 날씨 정보를 활용
- 해당 장소/상황에서 있을 법한 장면을 상상하여 작성
- "사진이 없다", "이미지를 볼 수 없다" 등의 표현은 절대 사용하지 마세요
"""

    prompt = f"""{photo_instruction}

**정보:**
- 위치: {location}
- 관계: {relation}
- 해시태그: {hashtag_context or '없음'}
- {weather_context or '날씨 정보 없음'}

**작업:** 
두 가지 스타일로 각각 3개씩, 총 6개의 문장을 만들어주세요.

**스타일 1 - MZ감성:** 감성적, 트렌디, 인스타 캡션 느낌
**스타일 2 - 아재개그:** 아빠 개그, 말장난, 건조한 유머

**규칙:**
- 각 문장은 50자 이내 (공백 포함)
- 이모지, 해시태그 사용 금지
- "제주" 언급은 위치에 제주가 있을 때만
- "사진이 없다", "이미지를 볼 수 없다" 등의 표현 금지

**출력 형식:**
MZ1: 문장
MZ2: 문장
MZ3: 문장
AJAE1: 문장
AJAE2: 문장
AJAE3: 문장
"""

    try:
        user_content = [{"type": "text", "text": prompt}]
        if has_images and not TEXT_ONLY_CAPTION:
            user_content.extend(image_contents)
        
        response = client.chat.completions.create(
            model="gpt-4o-mini",  # 빠른 응답을 위해 mini 사용
            messages=[
                {
                    "role": "system", 
                    "content": "당신은 한국어 문구 작성 전문가입니다. 짧고 임팩트 있는 문장을 작성합니다. 사진이 없어도 주어진 정보로 창의적인 문장을 만들 수 있습니다."
                },
                {"role": "user", "content": user_content},
            ],
            temperature=0.9,
            max_tokens=1000
        )
        
        result_text = (response.choices[0].message.content or "").strip()
        
        # 응답 파싱
        mz_captions = []
        ajae_captions = []
        
        for line in result_text.split('\n'):
            line = line.strip()
            if line.startswith("MZ") and ":" in line:
                caption = line.split(":", 1)[1].strip()
                # 대괄호 제거
                caption = caption.strip("[]")
                # 50자 제한
                if len(caption) > 50:
                    caption = caption[:50]
                if caption:
                    mz_captions.append(caption)
            elif line.startswith("AJAE") and ":" in line:
                caption = line.split(":", 1)[1].strip()
                caption = caption.strip("[]")
                if len(caption) > 50:
                    caption = caption[:50]
                if caption:
                    ajae_captions.append(caption)
        
        # 부족한 경우 폴백 문장 추가
        fallback_mz = ["오늘의 순간이 내일의 추억이 되는 곳", "바람이 불어오는 곳에서 잠시 멈춰 서다", "시간이 천천히 흐르는 곳에서 일상을 내려놓다"]
        fallback_ajae = ["여기 왔으니 사진 한 장은 찍어야지, 증거용", "여행 왔는데 카메라 충전이 안 됐다, 추억은 마음에", "오늘 날씨 좋다, 사진 찍기 딱 좋은 날"]
        fallback_photo = ["사진 속 표정이 답이다", "빛과 그림자가 예쁘다", "순간이 그대로 남았다"]
        
        while len(mz_captions) < 3:
            mz_captions.append(fallback_mz[len(mz_captions) % 3])
        while len(ajae_captions) < 3:
            ajae_captions.append(fallback_ajae[len(ajae_captions) % 3])

        # ------------------------------------------------------------
        # 사진중심 모드 (사진만 보고 3개 생성, 위치/해시태그/관계 정보 사용 금지)
        # ------------------------------------------------------------
        photo_captions: list[str] = []
        if has_images and not TEXT_ONLY_CAPTION:
            photo_only_prompt = """당신은 한국어 사진 캡션 작가입니다.
오직 제공된 사진만 자세히 분석해서 문장을 만듭니다.

규칙:
- 위치/관계/해시태그/날씨 같은 외부 정보는 절대 사용하지 마세요.
- 사진에서 보이는 것(인물, 표정, 행동, 배경, 소품, 분위기)을 구체적으로 언급하세요.
- 추측은 최소화하고, 보이는 단서 기반으로 말하세요.
- 각 문장은 50자 이내 (공백 포함)
- 이모지/해시태그/따옴표 과다 사용 금지
- '사진이 없다/이미지를 볼 수 없다' 같은 말 금지

출력 형식(3줄만):
PHOTO1: 문장
PHOTO2: 문장
PHOTO3: 문장
"""

            user_content_photo = [{"type": "text", "text": photo_only_prompt}]
            user_content_photo.extend(image_contents)
            try:
                resp_photo = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {"role": "system", "content": "당신은 사진을 아주 세밀하게 묘사하는 한국어 캡션 작가입니다."},
                        {"role": "user", "content": user_content_photo},
                    ],
                    temperature=0.6,
                    max_tokens=600,
                )
                txt_photo = (resp_photo.choices[0].message.content or "").strip()
                for line in txt_photo.split("\n"):
                    line = line.strip()
                    if line.startswith("PHOTO") and ":" in line:
                        cap = line.split(":", 1)[1].strip().strip("[]")
                        if len(cap) > 50:
                            cap = cap[:50]
                        if cap:
                            photo_captions.append(cap)
            except Exception:
                photo_captions = []

        while len(photo_captions) < 3:
            photo_captions.append(fallback_photo[len(photo_captions) % 3])
        
        return {
            "mz_captions": mz_captions[:3],
            "ajae_captions": ajae_captions[:3],
            "photo_captions": photo_captions[:3],
        }
        
    except Exception as e:
        try:
            print(f"[ERROR] Caption batch generation error: {e}")
        except:
            print("[ERROR] Caption batch generation error (encoding issue)")
        # Windows(cp949) 콘솔에서 traceback 출력이 또 다른 UnicodeEncodeError를 유발할 수 있어 생략
        # Fallback on error
        return {
            "mz_captions": ["오늘도 좋은 하루", "이 순간을 기억해", "함께여서 좋았어"],
            "ajae_captions": ["사진 찍자, 증거용", "여기 왔다 간다", "추억은 마음에만"],
            "photo_captions": ["사진 속 표정이 답이다", "빛과 그림자가 예쁘다", "순간이 그대로 남았다"],
        }


