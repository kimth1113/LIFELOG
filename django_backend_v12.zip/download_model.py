from ultralytics import YOLO
import os

# 현재 디렉토리 (backend/)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "yolov8n.pt")

print(f"Downloading/Loading YOLO model to {MODEL_PATH}...")
model = YOLO("yolov8n.pt")  # 자동으로 다운로드됨 (현재 작업 디렉토리 기준)
model.save(MODEL_PATH)      # 명시적으로 backend/yolov8n.pt로 저장
print("[OK] Model downloaded successfully.")

